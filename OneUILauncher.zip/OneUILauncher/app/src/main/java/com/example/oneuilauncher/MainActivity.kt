package com.example.oneuilauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object LauncherBus { val homePress = mutableIntStateOf(0) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
        )
        setContent { LauncherScreen() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) LauncherBus.homePress.intValue++   // Home button pressed
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LauncherScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { Store(ctx) }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var home by remember { mutableStateOf(store.get("home")) }
    var dock by remember { mutableStateOf(store.get("dock")) }

    fun reload() { scope.launch { apps = withContext(Dispatchers.IO) { loadApps(ctx) } } }
    LaunchedEffect(Unit) { reload() }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { reload() } }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { ctx.unregisterReceiver(r) }
    }
    LaunchedEffect(apps) {
        if (apps.isNotEmpty() && !store.has("home")) {
            val (d, h) = defaultLayout(ctx, apps)
            store.set("dock", d); store.set("home", h); dock = d; home = h
        }
    }
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    val homeApps = home.mapNotNull { byPkg[it] }
    val dockApps = dock.mapNotNull { byPkg[it] }
    val pages = homePages(homeApps)
    val pager = rememberPagerState { pages.size }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val hPx = with(LocalDensity.current) { maxHeight.toPx() }
        val panel = remember { Animatable(0f) }
        val drawer = remember { Animatable(0f) }
        var expanded by remember { mutableStateOf(false) }

        fun settle(a: Animatable<Float, AnimationVector1D>, open: Boolean) = scope.launch {
            a.animateTo(if (open) 1f else 0f, spring(dampingRatio = 0.9f, stiffness = 380f))
        }
        fun closeAll() {
            settle(drawer, false)
            scope.launch { panel.animateTo(0f, spring(dampingRatio = 0.9f, stiffness = 380f)); expanded = false }
        }

        LaunchedEffect(LauncherBus.homePress.intValue) {
            if (LauncherBus.homePress.intValue > 0) { closeAll(); pager.animateScrollToPage(0) }
        }
        BackHandler(enabled = drawer.value > 0f || panel.value > 0f) { closeAll() }

        Box(
            Modifier.fillMaxSize()
                // wallpaper legibility gradient + dim while sheets are open
                .drawBehind {
                    drawRect(Brush.verticalGradient(listOf(Color.Black.copy(0.18f), Color.Transparent, Color.Black.copy(0.30f))))
                    drawRect(Color.Black.copy(0.45f * maxOf(panel.value, drawer.value)))
                }
                // swipe down from the top = panel, swipe up elsewhere = app drawer
                .pointerInput(Unit) {
                    var mode = 0
                    detectVerticalDragGestures(
                        onDragStart = { o ->
                            mode = when {
                                panel.value > 0f || drawer.value > 0f -> 0
                                o.y < size.height * 0.30f -> 1
                                else -> 2
                            }
                        },
                        onVerticalDrag = { _, dy ->
                            when (mode) {
                                1 -> scope.launch { panel.snapTo((panel.value + dy / (size.height * 0.6f)).coerceIn(0f, 1f)) }
                                2 -> scope.launch { drawer.snapTo((drawer.value - dy / (size.height * 0.7f)).coerceIn(0f, 1f)) }
                            }
                        },
                        onDragEnd = {
                            if (mode == 1) settle(panel, panel.value > 0.25f)
                            if (mode == 2) settle(drawer, drawer.value > 0.25f)
                            mode = 0
                        },
                        onDragCancel = { settle(panel, false); settle(drawer, false); mode = 0 },
                    )
                },
        ) {
            // ---------- Home ----------
            Column(
                Modifier.fillMaxSize()
                    .graphicsLayer {
                        val p = drawer.value
                        scaleX = 1f - 0.08f * p; scaleY = 1f - 0.08f * p; alpha = 1f - p
                    }
                    .statusBarsPadding().navigationBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                HomePager(
                    pager, pages,
                    onRemove = { a -> home = home - a.pkg; store.set("home", home) },
                    modifier = Modifier.weight(1f),
                )
                PageDots(pages.size, pager.currentPage)
                Dock(dockApps) { a -> dock = dock - a.pkg; store.set("dock", dock) }
                Spacer(Modifier.height(10.dp))
            }

            // ---------- App drawer ----------
            if (drawer.value > 0f) {
                Drawer(
                    apps, (home + dock).toSet(), { drawer.value },
                    onPin = { a ->
                        if (a.pkg in home) home = home - a.pkg
                        else if (a.pkg !in dock) home = home + a.pkg
                        store.set("home", home)
                    },
                    onDragBy = { dy -> scope.launch { drawer.snapTo((drawer.value - dy / (hPx * 0.7f)).coerceIn(0f, 1f)) } },
                    onRelease = { settle(drawer, drawer.value > 0.6f) },
                )
            }

            // ---------- Notification / quick panel ----------
            if (panel.value > 0f) {
                Box(Modifier.fillMaxSize().clickable(remember { MutableInteractionSource() }, null) { closeAll() })
                QuickPanel(
                    progress = { panel.value },
                    expanded = expanded,
                    apps = byPkg,
                    onToggleExpand = { expanded = !expanded },
                    onDragBy = { dy -> scope.launch { panel.snapTo((panel.value + dy / (hPx * 0.6f)).coerceIn(0f, 1f)) } },
                    onRelease = { settle(panel, panel.value > 0.7f) },
                    onClose = { closeAll() },
                )
            }
        }
    }
}
