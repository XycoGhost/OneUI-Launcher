package com.example.oneuilauncher

import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Tile(
    val label: String, val icon: ImageVector, val active: Boolean,
    val sub: String? = null, val onClick: () -> Unit,
)

private fun Context.go(i: Intent) { runCatching { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
private fun Context.writeSettingsPrompt() =
    go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))

private fun buildTiles(ctx: Context, torch: Boolean, cam: CameraManager, camId: String?): List<Tile> {
    val wifi = ctx.applicationContext.getSystemService(WifiManager::class.java)
    val nm = ctx.getSystemService(NotificationManager::class.java)
    val audio = ctx.getSystemService(AudioManager::class.java)
    val lm = ctx.getSystemService(LocationManager::class.java)
    val pw = ctx.getSystemService(PowerManager::class.java)
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    val cr = ctx.contentResolver

    val wifiOn = runCatching { wifi.isWifiEnabled }.getOrDefault(false)
    val btOn = Settings.Global.getInt(cr, "bluetooth_on", 0) == 1
    val dnd = nm.currentInterruptionFilter.let {
        it != NotificationManager.INTERRUPTION_FILTER_ALL && it != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }
    val rotate = Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
    val air = Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    val loc = lm.isLocationEnabled
    val saver = pw.isPowerSaveMode
    val cellular = cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
    val ringer = audio.ringerMode

    return listOf(
        Tile("Wi-Fi", Icons.Rounded.Wifi, wifiOn, if (wifiOn) "On" else "Off") {
            ctx.go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
        },
        Tile("Bluetooth", Icons.Rounded.Bluetooth, btOn, if (btOn) "On" else "Off") {
            ctx.go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        },
        Tile(
            when (ringer) { AudioManager.RINGER_MODE_NORMAL -> "Sound"; AudioManager.RINGER_MODE_VIBRATE -> "Vibrate"; else -> "Mute" },
            when (ringer) { AudioManager.RINGER_MODE_NORMAL -> Icons.Rounded.VolumeUp; AudioManager.RINGER_MODE_VIBRATE -> Icons.Rounded.Vibration; else -> Icons.Rounded.VolumeOff },
            ringer == AudioManager.RINGER_MODE_NORMAL,
        ) {
            val next = when (ringer) {
                AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE
                AudioManager.RINGER_MODE_VIBRATE -> AudioManager.RINGER_MODE_SILENT
                else -> AudioManager.RINGER_MODE_NORMAL
            }
            runCatching { audio.ringerMode = next }.onFailure {
                ctx.go(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        },
        Tile("Flashlight", Icons.Rounded.FlashlightOn, torch) { camId?.let { runCatching { cam.setTorchMode(it, !torch) } } },
        Tile("Do not disturb", Icons.Rounded.DoNotDisturbOn, dnd) {
            if (nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(
                    if (dnd) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
                )
            } else ctx.go(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        },
        Tile("Auto rotate", Icons.Rounded.ScreenRotation, rotate) {
            if (Settings.System.canWrite(ctx))
                Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, if (rotate) 0 else 1)
            else ctx.writeSettingsPrompt()
        },
        Tile("Airplane", Icons.Rounded.AirplanemodeActive, air) { ctx.go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) },
        Tile("Location", Icons.Rounded.LocationOn, loc) { ctx.go(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) },
        Tile("Mobile data", Icons.Rounded.SignalCellularAlt, cellular) { ctx.go(Intent(Settings.ACTION_WIRELESS_SETTINGS)) },
        Tile("Battery saver", Icons.Rounded.BatterySaver, saver) { ctx.go(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) },
        Tile("Hotspot", Icons.Rounded.WifiTethering, false) {
            ctx.go(Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"))
        },
        Tile("NFC", Icons.Rounded.Nfc, false) { ctx.go(Intent(Settings.Panel.ACTION_NFC)) },
    )
}

@Composable
fun QuickPanel(
    progress: () -> Float,
    expanded: Boolean,
    apps: Map<String, AppInfo>,
    onToggleExpand: () -> Unit,
    onDragBy: (Float) -> Unit,
    onRelease: () -> Unit,
    onClose: () -> Unit,
) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(700); tick++ } }

    var torch by remember { mutableStateOf(false) }
    val cam = remember { ctx.getSystemService(CameraManager::class.java) }
    val camId = remember {
        runCatching {
            cam.cameraIdList.firstOrNull { cam.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        }.getOrNull()
    }
    DisposableEffect(Unit) {
        val cb = object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { if (cameraId == camId) torch = enabled }
        }
        cam.registerTorchCallback(cb, null)
        onDispose { cam.unregisterTorchCallback(cb) }
    }
    val tiles = remember(tick, torch) { buildTiles(ctx, torch, cam, camId) }
    val now = remember(tick) { Date() }
    val battery = remember(tick) {
        ctx.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }
    val listenerOn = remember(tick) {
        Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")?.contains(ctx.packageName) == true
    }
    val notifs = NotifStore.items

    Column(
        Modifier.fillMaxWidth()
            .slideY { h -> -(1f - progress()) * h }
            .heightIn(max = 760.dp)
            .clip(RoundedCornerShape(bottomStart = 34.dp, bottomEnd = 34.dp))
            .background(OneUi.PanelBg)
            .statusBarsPadding()
            .animateContentSize(),
    ) {
        // ---- header ----
        Row(
            Modifier.fillMaxWidth().dragSheet(onDragBy, onRelease).padding(start = 24.dp, end = 12.dp, top = 12.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(SimpleDateFormat("h:mm", Locale.getDefault()).format(now), color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Light)
                Text(SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(now) + "  ·  $battery%", color = OneUi.TextDim, fontSize = 14.sp)
            }
            IconBtn(Icons.Rounded.PowerSettingsNew) { ctx.go(Intent(Settings.ACTION_SETTINGS)) }
            IconBtn(Icons.Rounded.Settings) { ctx.go(Intent(Settings.ACTION_SETTINGS)) }
        }

        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            // ---- tiles ----
            if (!expanded) {
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    tiles.take(6).forEach { CircleTile(it, 52.dp, showLabel = false) }
                }
            } else {
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    tiles.take(2).forEach { WideTile(it, Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(14.dp))
                tiles.drop(2).chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        row.forEach { CircleTile(it, 62.dp, showLabel = true, Modifier.width(72.dp)) }
                        repeat(4 - row.size) { Spacer(Modifier.width(72.dp)) }
                    }
                }
                BrightnessBar(tick)
                Spacer(Modifier.height(8.dp))
            }

            MediaCard(tick)

            // ---- notifications (collapsed view) ----
            if (!expanded) {
                if (!listenerOn) {
                    Row(
                        Modifier.padding(top = 10.dp).fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(OneUi.Card)
                            .clickable { ctx.go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Rounded.NotificationsNone, null, tint = OneUi.Accent)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Show notifications here", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("Tap to allow notification access", color = OneUi.TextDim, fontSize = 13.sp)
                        }
                    }
                } else if (notifs.isEmpty()) {
                    Text("No notifications", color = OneUi.TextDim, fontSize = 14.sp, modifier = Modifier.padding(vertical = 22.dp).align(Alignment.CenterHorizontally))
                } else {
                    notifs.forEach { NotificationCard(it, apps) }
                }
            }
            Spacer(Modifier.height(6.dp))
        }

        // ---- footer ----
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(if (expanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown) { onToggleExpand() }
            Spacer(Modifier.weight(1f))
            if (!expanded && notifs.isNotEmpty()) {
                Text(
                    "Clear all", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(CircleShape).background(OneUi.TileOff).clickable { NotifStore.service?.cancelAllNotifications() }
                        .padding(horizontal = 18.dp, vertical = 9.dp),
                )
            }
        }
        Box(Modifier.fillMaxWidth().dragSheet(onDragBy, onRelease).clickable { onClose() }.padding(top = 4.dp, bottom = 14.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(40.dp, 4.dp).background(Color.White.copy(0.4f), RoundedCornerShape(2.dp)))
        }
    }
}

@Composable
private fun IconBtn(icon: ImageVector, onClick: () -> Unit) {
    IconButton(onClick) { Icon(icon, null, tint = Color.White.copy(0.9f)) }
}

@Composable
private fun CircleTile(t: Tile, size: androidx.compose.ui.unit.Dp, showLabel: Boolean, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(size).clip(CircleShape).background(if (t.active) OneUi.Accent else OneUi.TileOff).clickable { t.onClick() },
            contentAlignment = Alignment.Center,
        ) { Icon(t.icon, t.label, tint = if (t.active) Color.White else Color.White.copy(0.75f), modifier = Modifier.size(size * 0.45f)) }
        if (showLabel) {
            Spacer(Modifier.height(6.dp))
            Text(t.label, color = Color.White.copy(0.85f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun WideTile(t: Tile, modifier: Modifier) {
    Row(
        modifier.height(68.dp).clip(RoundedCornerShape(34.dp)).background(if (t.active) OneUi.Accent else OneUi.TileOff)
            .clickable { t.onClick() }.padding(start = 10.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(48.dp).background(Color.White.copy(if (t.active) 0.22f else 0.10f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(t.icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(t.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            t.sub?.let { Text(it, color = Color.White.copy(0.7f), fontSize = 12.sp, maxLines = 1) }
        }
    }
}

@Composable
private fun BrightnessBar(tick: Int) {
    val ctx = LocalContext.current
    fun read() = (Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f).coerceIn(0f, 1f)
    var v by remember { mutableFloatStateOf(read()) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(tick) { if (!dragging) v = read() }
    fun set(f: Float) {
        v = f.coerceIn(0f, 1f)
        if (Settings.System.canWrite(ctx)) {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (v * 255).toInt().coerceAtLeast(8))
        }
    }
    var width by remember { mutableFloatStateOf(1f) }
    Box(
        Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp)).background(OneUi.TileOff)
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    if (!Settings.System.canWrite(ctx)) ctx.writeSettingsPrompt() else set(o.x / size.width)
                }
            }
            .pointerInput(Unit) {
                width = size.width.toFloat()
                detectHorizontalDragGestures(
                    onDragStart = { dragging = true; if (!Settings.System.canWrite(ctx)) ctx.writeSettingsPrompt() },
                    onDragEnd = { dragging = false }, onDragCancel = { dragging = false },
                ) { c, _ -> set(c.position.x / size.width) }
            },
    ) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(v.coerceAtLeast(0.12f)).background(Color.White.copy(0.92f), RoundedCornerShape(26.dp)))
        Icon(Icons.Rounded.BrightnessHigh, null, tint = Color(0xFF202022), modifier = Modifier.padding(start = 16.dp).align(Alignment.CenterStart))
    }
}

@Composable
private fun MediaCard(tick: Int) {
    val mc = NotifStore.media ?: return
    val md = remember(tick, mc) { mc.metadata }
    val playing = remember(tick, mc) { mc.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING }
    val title = md?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: return
    val artist = md.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: ""
    val art = md.getBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(android.media.MediaMetadata.METADATA_KEY_ART)
    Row(
        Modifier.padding(top = 10.dp).fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(OneUi.Card).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(OneUi.TileOff)) {
            if (art != null) Image(art.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(artist, color = OneUi.TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconBtn(Icons.Rounded.SkipPrevious) { mc.transportControls.skipToPrevious() }
        IconBtn(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow) {
            if (playing) mc.transportControls.pause() else mc.transportControls.play()
        }
        IconBtn(Icons.Rounded.SkipNext) { mc.transportControls.skipToNext() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotificationCard(sbn: android.service.notification.StatusBarNotification, apps: Map<String, AppInfo>) {
    val n = sbn.notification
    val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
    val text = (n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: n.extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
    val app = apps[sbn.packageName]
    val state = rememberSwipeToDismissBoxState(confirmValueChange = {
        if (it != SwipeToDismissBoxValue.Settled && sbn.isClearable) { NotifStore.service?.cancelNotification(sbn.key); true } else false
    })
    SwipeToDismissBox(state, backgroundContent = {}, modifier = Modifier.padding(top = 10.dp)) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(OneUi.Card)
                .clickable {
                    runCatching { n.contentIntent?.send() }
                    if (n.flags and Notification.FLAG_AUTO_CANCEL != 0) NotifStore.service?.cancelNotification(sbn.key)
                }.padding(horizontal = 16.dp, vertical = 14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (app != null) Image(app.icon, null, Modifier.size(20.dp).clip(RoundedCornerShape(6.dp)))
                Spacer(Modifier.width(8.dp))
                Text(app?.label ?: sbn.packageName, color = OneUi.TextDim, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                Text(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(sbn.postTime)), color = OneUi.TextDim, fontSize = 12.sp)
            }
            if (title.isNotEmpty()) Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
            if (text.isNotEmpty()) Text(text, color = Color.White.copy(0.8f), fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
        }
    }
}
