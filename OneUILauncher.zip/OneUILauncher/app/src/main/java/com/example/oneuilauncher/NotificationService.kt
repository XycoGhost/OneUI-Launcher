package com.example.oneuilauncher

import android.content.ComponentName
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Shared state the quick panel reads. */
object NotifStore {
    var items by mutableStateOf<List<StatusBarNotification>>(emptyList())
    var media by mutableStateOf<MediaController?>(null)
    var service: NotificationListenerService? = null
}

class OneUiNotificationService : NotificationListenerService() {
    override fun onListenerConnected() { NotifStore.service = this; refresh() }
    override fun onListenerDisconnected() { NotifStore.service = null }
    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()

    private fun refresh() {
        runCatching {
            NotifStore.items = activeNotifications
                .filter { it.notification.flags and Notification.FLAG_GROUP_SUMMARY == 0 }
                .filter { it.notification.extras.getCharSequence(Notification.EXTRA_TITLE) != null ||
                          it.notification.extras.getCharSequence(Notification.EXTRA_TEXT) != null }
                .sortedByDescending { it.postTime }
        }
        runCatching {
            val msm = getSystemService(MediaSessionManager::class.java)
            NotifStore.media = msm.getActiveSessions(ComponentName(this, OneUiNotificationService::class.java)).firstOrNull()
        }
    }
}
