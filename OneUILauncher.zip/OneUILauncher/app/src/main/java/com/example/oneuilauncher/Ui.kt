package com.example.oneuilauncher

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import kotlin.math.roundToInt

object OneUi {
    val Accent = Color(0xFF3E91FF)
    val PanelBg = Color(0xFF141416)
    val Card = Color(0xFF242427)
    val TileOff = Color(0xFF303033)
    val TextDim = Color(0xFFA8A8AD)
    val DrawerBg = Color(0xEB0C0C0E)
}

/** Vertical drag helper for sheets (positive dy = finger moving down). */
fun Modifier.dragSheet(onDragBy: (Float) -> Unit, onRelease: () -> Unit): Modifier =
    pointerInput(Unit) {
        detectVerticalDragGestures(onDragEnd = onRelease, onDragCancel = onRelease) { _, dy -> onDragBy(dy) }
    }

/** Offsets a composable in the layout phase (no first-frame flash, no recomposition per frame). */
fun Modifier.slideY(offset: (height: Int) -> Float): Modifier = layout { m, c ->
    val p = m.measure(c)
    layout(p.width, p.height) { p.placeRelative(0, offset(p.height).roundToInt()) }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: AppInfo,
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 60.dp,
    showLabel: Boolean = true,
    menu: List<Pair<String, () -> Unit>> = emptyList(),
) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val inter = remember { MutableInteractionSource() }
    val pressed by inter.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.86f else 1f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium), label = "press"
    )
    Box(modifier, contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .combinedClickable(inter, null, onClick = { launchApp(ctx, app) }, onLongClick = { open = true })
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                app.icon, app.label,
                Modifier.size(size).shadow(6.dp, RoundedCornerShape(size * 0.3f), clip = false, ambientColor = Color.Black.copy(0.3f)).clip(RoundedCornerShape(size * 0.3f)),
            )
            if (showLabel) {
                Spacer(Modifier.height(5.dp))
                Text(
                    app.label, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    style = TextStyle(shadow = Shadow(Color.Black.copy(0.55f), Offset(0f, 2f), 6f)),
                    modifier = Modifier.width(size + 12.dp),
                )
            }
        }
        DropdownMenu(
            expanded = open, onDismissRequest = { open = false },
            shape = RoundedCornerShape(22.dp), containerColor = Color(0xFF2A2A2D),
        ) {
            menu.forEach { (title, action) ->
                DropdownMenuItem(
                    text = { Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium) },
                    onClick = { open = false; action() },
                )
            }
        }
    }
}
