package com.example.oneuilauncher

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Drawer(
    apps: List<AppInfo>,
    pinned: Set<String>,
    progress: () -> Float,
    onPin: (AppInfo) -> Unit,
    onDragBy: (Float) -> Unit,
    onRelease: () -> Unit,
) {
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    var query by remember { mutableStateOf("") }
    val shown = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    val nested = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < 0f && progress() < 1f) { onDragBy(available.y); return Offset(0f, available.y) }
                return Offset.Zero
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 0f && source == NestedScrollSource.UserInput) { onDragBy(available.y); return Offset(0f, available.y) }
                return Offset.Zero
            }
            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                if (progress() < 1f) onRelease()
                return Velocity.Zero
            }
        }
    }
    Column(
        Modifier.fillMaxSize()
            .slideY { h -> (1f - progress()) * h }
            .clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
            .background(OneUi.DrawerBg)
            .statusBarsPadding()
            .nestedScroll(nested),
    ) {
        Box(Modifier.fillMaxWidth().dragSheet(onDragBy, onRelease).padding(top = 10.dp, bottom = 6.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(36.dp, 4.dp).background(Color.White.copy(0.35f), RoundedCornerShape(2.dp)))
        }
        // Search pill
        Row(
            Modifier.padding(horizontal = 18.dp, vertical = 6.dp).fillMaxWidth().height(52.dp)
                .background(Color.White.copy(0.12f), RoundedCornerShape(26.dp)).padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Search, null, tint = Color.White.copy(0.7f))
            Spacer(Modifier.width(12.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) Text("Search apps", color = Color.White.copy(0.55f), fontSize = 16.sp)
                BasicTextField(
                    query, { query = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(OneUi.Accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { shown.firstOrNull()?.let { launchApp(ctx, it) }; focus.clearFocus() }),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        LazyVerticalGrid(
            GridCells.Fixed(4), Modifier.weight(1f),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 24.dp + 48.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            items(shown, key = { it.pkg }) { app ->
                AppIcon(
                    app, Modifier.fillMaxWidth(),
                    menu = buildList {
                        add((if (app.pkg in pinned) "Remove from Home" else "Add to Home") to { onPin(app) })
                        add("App info" to { openAppInfo(ctx, app.pkg); Unit })
                        add("Uninstall" to { uninstallApp(ctx, app.pkg); Unit })
                    },
                )
            }
        }
    }
}
