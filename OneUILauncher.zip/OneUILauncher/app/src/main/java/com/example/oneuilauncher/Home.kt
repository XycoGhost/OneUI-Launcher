package com.example.oneuilauncher

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val COLS = 4
const val PAGE0_ROWS = 3   // page 0 shares space with the clock widget
const val ROWS = 5

fun homePages(apps: List<AppInfo>): List<List<AppInfo>> {
    val first = apps.take(COLS * PAGE0_ROWS)
    return listOf(first) + apps.drop(first.size).chunked(COLS * ROWS)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomePager(pager: PagerState, pages: List<List<AppInfo>>, onRemove: (AppInfo) -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    HorizontalPager(pager, modifier) { page ->
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
            val rows = if (page == 0) PAGE0_ROWS else ROWS
            if (page == 0) {
                ClockWidget(Modifier.weight((ROWS - PAGE0_ROWS).toFloat()).fillMaxWidth())
            }
            val items = pages.getOrElse(page) { emptyList() }
            repeat(rows) { r ->
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    repeat(COLS) { c ->
                        val app = items.getOrNull(r * COLS + c)
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            if (app != null) AppIcon(
                                app,
                                menu = listOf(
                                    "App info" to { openAppInfo(ctx, app.pkg); Unit },
                                    "Remove from Home" to { onRemove(app) },
                                    "Uninstall" to { uninstallApp(ctx, app.pkg); Unit },
                                ),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ClockWidget(modifier: Modifier = Modifier) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(5_000) } }
    val shadow = TextStyle(shadow = Shadow(Color.Black.copy(0.35f), Offset(0f, 3f), 10f))
    Column(modifier.padding(start = 10.dp, top = 24.dp), verticalArrangement = Arrangement.Center) {
        Text(SimpleDateFormat("h:mm", Locale.getDefault()).format(now), color = Color.White, fontSize = 76.sp, fontWeight = FontWeight.Light, style = shadow)
        Text(SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(now), color = Color.White.copy(0.92f), fontSize = 16.sp, fontWeight = FontWeight.Medium, style = shadow)
    }
}

@Composable
fun PageDots(count: Int, current: Int) {
    if (count < 2) return
    Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        repeat(count) {
            Box(Modifier.size(if (it == current) 7.dp else 6.dp).background(Color.White.copy(if (it == current) 1f else 0.45f), CircleShape))
        }
    }
}

@Composable
fun Dock(apps: List<AppInfo>, onRemove: (AppInfo) -> Unit) {
    val ctx = LocalContext.current
    Row(
        Modifier.padding(horizontal = 14.dp).fillMaxWidth()
            .background(Color.White.copy(alpha = 0.20f), RoundedCornerShape(34.dp))
            .padding(horizontal = 8.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
    ) {
        apps.forEach { app ->
            AppIcon(
                app, size = 58.dp, showLabel = false,
                menu = listOf(
                    "App info" to { openAppInfo(ctx, app.pkg); Unit },
                    "Remove from dock" to { onRemove(app) },
                ),
            )
        }
    }
}
