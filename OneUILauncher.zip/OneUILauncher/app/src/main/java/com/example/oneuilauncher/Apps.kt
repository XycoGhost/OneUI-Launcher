package com.example.oneuilauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppInfo(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val icon: ImageBitmap,
)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { ri ->
            AppInfo(
                label = ri.loadLabel(pm).toString(),
                pkg = ri.activityInfo.packageName,
                component = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name),
                icon = ri.loadIcon(pm).toBitmap(160, 160).asImageBitmap(),
            )
        }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, app: AppInfo) {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(app.component)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    runCatching { ctx.startActivity(i) }
}

fun openAppInfo(ctx: Context, pkg: String) = runCatching {
    ctx.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

fun uninstallApp(ctx: Context, pkg: String) = runCatching {
    ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

/** Tiny persistence for the home/dock lists. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("oneui_launcher", Context.MODE_PRIVATE)
    fun has(key: String) = p.contains(key)
    fun get(key: String): List<String> =
        p.getString(key, "")!!.split(",").filter { it.isNotEmpty() }
    fun set(key: String, v: List<String>) = p.edit().putString(key, v.joinToString(",")).apply()
}

/** First-run layout: dock (phone, messages, browser, camera) + common apps on home. */
fun defaultLayout(ctx: Context, apps: List<AppInfo>): Pair<List<String>, List<String>> {
    val pm = ctx.packageManager
    val have = apps.map { it.pkg }.toSet()
    fun sel(c: String) = pm.resolveActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, c), 0)?.activityInfo?.packageName
    fun act(i: Intent) = pm.resolveActivity(i, 0)?.activityInfo?.packageName
    val dock = listOfNotNull(
        act(Intent(Intent.ACTION_DIAL)),
        sel(Intent.CATEGORY_APP_MESSAGING),
        sel(Intent.CATEGORY_APP_BROWSER),
        act(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)),
    ).filter { it in have }.distinct()
    val home = listOfNotNull(
        sel(Intent.CATEGORY_APP_GALLERY), sel(Intent.CATEGORY_APP_CALENDAR), sel(Intent.CATEGORY_APP_CONTACTS),
        sel(Intent.CATEGORY_APP_EMAIL), sel(Intent.CATEGORY_APP_MAPS), sel(Intent.CATEGORY_APP_MUSIC),
        sel(Intent.CATEGORY_APP_CALCULATOR),
        act(Intent(Settings.ACTION_SETTINGS)), "com.android.vending",
    ).filter { it in have && it !in dock }.distinct()
    return dock to home
}
