# One UI Launcher (redesign)

Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then
Build > Build APK(s). Output: app/build/outputs/apk/release/app-release.apk

First run: set it as the default Home app, then in the launcher swipe down and tap
"Show notifications here" to grant notification access. Tap the brightness bar once to grant
"Modify system settings" (needed for brightness and auto-rotate).
